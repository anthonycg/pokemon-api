import logo from './logo.svg';
import './App.css';
import PokemonCall from './components/PokemonCall';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <PokemonCall/>
      </header>
    </div>
  );
}

export default App;
